// backend/index.js
const express = require("express");
const cors    = require("cors");

/* ---------- Módulos de rutas ---------- */
const authRoutes     = require("./routes/auth");      // login y registro
const usuarioRoutes  = require("./routes/usuario");   // edición de datos del usuario
const reportesRoutes = require("./routes/reportes");  // creación / consulta de reportes

const app = express();

/* ---------- Middlewares globales ---------- */
app.use(cors());             // permite peticiones cross-origin (localhost:5500 → 3000)
app.use(express.json());     // parsea cuerpos JSON

/* ---------- Montaje de rutas ---------- */
app.use("/api", authRoutes);        //  /api/login   |  /api/registro
app.use("/api", usuarioRoutes);     //  /api/usuario/:id   (PUT)
app.use("/api", reportesRoutes);    //  /api/reportes      (POST, GET …)

/* ---------- Arranque del servidor ---------- */
const PORT = 3000;
app.listen(PORT, () =>
  console.log(`🚀 Servidor backend corriendo en http://localhost:${PORT}`)
);