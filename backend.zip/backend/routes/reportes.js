// backend/routes/reportes.js
const express = require("express");
const router  = express.Router();
const db      = require("../db");

/* =======================================================
   POST /api/reportes
   Body: { id_servicio, tipo_falla, ubicacion, descripcion }
   ======================================================= */
router.post("/reportes", (req, res) => {
  const { id_servicio, tipo_falla, ubicacion, descripcion } = req.body;

  if (!id_servicio || !tipo_falla || !ubicacion || !descripcion) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `
    INSERT INTO reportes
      (id_servicio, tipo_falla, ubicacion, descripcion,
       fecha_reporte, estatus)
    VALUES (?, ?, ?, ?, NOW(), 'Pendiente')
  `;

  db.query(sql, [id_servicio, tipo_falla, ubicacion, descripcion], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Error al guardar el reporte" });
    }
    res.json({
      mensaje   : "Reporte guardado",
      id_reporte: result.insertId,
      estatus   : "Pendiente"
    });
  });
});

/* -------------------------------------------------------
   GET /api/reportes/servicio/:id_servicio
   Lista reportes de un servicio
   ------------------------------------------------------- */
router.get("/reportes/servicio/:id_servicio", (req, res) => {
  const { id_servicio } = req.params;

  db.query(
    `SELECT * FROM reportes WHERE id_servicio = ? ORDER BY fecha_reporte DESC`,
    [id_servicio],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Error al consultar reportes" });
      }
      res.json(rows);
    }
  );
});

/* -------------------------------------------------------
   GET /api/reporte/:id_reporte
   Obtiene un reporte individual
   ------------------------------------------------------- */
router.get("/reporte/:id_reporte", (req, res) => {
  const { id_reporte } = req.params;

  db.query(
    `SELECT * FROM reportes WHERE id_reporte = ? LIMIT 1`,
    [id_reporte],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Error al consultar" });
      }
      if (rows.length === 0)
        return res.status(404).json({ error: "Reporte no encontrado" });

      res.json(rows[0]);
    }
  );
});

module.exports = router;
