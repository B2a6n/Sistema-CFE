// backend/routes/reportes.js
const express = require("express");
const router  = express.Router();
const db      = require("../db");   // conexión mysql2

/* ===========================================================
   POST /api/reportes
   Crea un nuevo reporte de falla
   Body:
     {
       id_usuario,        // viene del localStorage → usuario.id_usuario
       tipo_falla,
       ubicacion,
       observaciones
     }
   =========================================================== */
router.post("/reportes", (req, res) => {
  console.log("Cuerpo recibido:", req.body);  // <-- AQUÍ
  const { id_usuario, tipo_falla, ubicacion, observaciones } = req.body;

  /* ------ Validación mínima ------ */
  if (!id_usuario || !tipo_falla || !ubicacion || !observaciones) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  /* ------ Paso 1: obtener id_servicio del usuario ------ */
  const sqlServicio = `
    SELECT id_servicio
    FROM   servicios
    WHERE  id_usuario = ?
    LIMIT  1
  `;

  db.query(sqlServicio, [id_usuario], (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Error al buscar el servicio" });
    }
    if (rows.length === 0) {
      return res.status(404).json({ error: "Servicio no encontrado" });
    }

    const id_servicio = rows[0].id_servicio;

    /* ------ Paso 2: insertar el reporte ------ */
    const sqlInsert = `
      INSERT INTO reportes
        (id_servicio, tipo_falla, ubicacion, descripcion,
         fecha_reporte, estatus)
      VALUES (?, ?, ?, ?, NOW(), 'Pendiente')
    `;

    db.query(
      sqlInsert,
      [id_servicio, tipo_falla, ubicacion, observaciones],
      (err2, result) => {
        if (err2) {
          console.error(err2);
          return res.status(500).json({ error: "Error al guardar el reporte" });
        }

        /* ------ Respuesta OK ------ */
        res.json({
          ok        : true,
          id_reporte: result.insertId,
          folio     : result.insertId,   // usa tu propio formato si lo deseas
          estatus   : "Pendiente"
        });
      }
    );
  });
});


/* ===========================================================
   GET /api/reportes/:id
   Devuelve TODO el reporte (para la pantalla de detalles)
   =========================================================== */
router.get("/reportes/:id", (req, res) => {
  db.query(
    "SELECT * FROM reportes WHERE id_reporte = ?",
    [req.params.id],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Error al consultar reporte" });
      }
      if (rows.length === 0) {
        return res.status(404).json({ error: "Reporte no encontrado" });
      }
      res.json(rows[0]);
    }
  );
});


/* ===========================================================
   GET /api/reportes/:id/estatus
   Devuelve sólo el estatus del reporte (polling cada 30 s)
   =========================================================== */
router.get("/reportes/:id/estatus", (req, res) => {
  db.query(
    "SELECT estatus FROM reportes WHERE id_reporte = ?",
    [req.params.id],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Error al consultar estatus" });
      }
      if (rows.length === 0) {
        return res.status(404).json({ error: "Reporte no encontrado" });
      }
      res.json(rows[0]);                 // { estatus: "Pendiente" | … }
    }
  );
});


/* ===========================================================
   GET /api/reportes/servicio/:id_servicio
   Lista todos los reportes de un servicio (historial)
   =========================================================== */
router.get("/reportes/servicio/:id_servicio", (req, res) => {
  db.query(
    "SELECT * FROM reportes WHERE id_servicio = ? ORDER BY fecha_reporte DESC",
    [req.params.id_servicio],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Error al consultar reportes" });
      }
      res.json(rows);
    }
  );
});

module.exports = router;
