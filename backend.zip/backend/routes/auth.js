// backend/routes/auth.js
const express = require('express');
const router  = express.Router();
const db      = require('../db');

/* ======================= LOGIN ======================== */
router.post('/login', (req, res) => {
  const { correo, contrasena } = req.body;

  if (!correo || !contrasena) {
    return res.status(400).json({ mensaje: 'Faltan datos de acceso' });
  }

  /* --- Consulta única que trae usuario + contrato + dirección --- */
  const sql = `
    SELECT  u.id_usuario, u.nombre, u.apellidos, u.correo, u.curp,
            u.telefono, u.fecha_nacimiento,
            s.id_servicio, s.numero_contrato,
            d.calle, d.numero, d.colonia, d.municipio,
            d.codigo_postal, d.estado
    FROM    usuarios u
    LEFT JOIN servicios s  ON s.id_usuario  = u.id_usuario
    LEFT JOIN direccion d  ON d.id_direccion = s.id_direccion
    WHERE   u.correo = ? AND u.contrasena = ?
    LIMIT 1
  `;

  db.query(sql, [correo, contrasena], (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Error de servidor' });
    }
    if (rows.length === 0) {
      return res.status(401).json({ mensaje: 'Credenciales incorrectas' });
    }

    return res.json({
      mensaje: 'Inicio de sesión exitoso',
      usuario: rows[0]          // ← trae todos los campos necesarios
    });
  });
});

/* ===================== REGISTRO ======================= */
router.post('/registro', (req, res) => {
  const {
    /* datos personales */
    nombre, apellidos, correo, contrasena,
    curp, telefono, fecha_nacimiento,
    /* dirección */
    calle, numero, colonia, municipio, codigo_postal, estado
  } = req.body;

  if (!nombre || !apellidos || !correo || !contrasena) {
    return res.status(400).json({ error: 'Datos incompletos' });
  }

  /* 1. insertar dirección */
  const sqlDir = `
    INSERT INTO direccion
      (calle, numero, colonia, municipio, codigo_postal, estado)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  db.query(sqlDir,
    [calle, numero, colonia, municipio, codigo_postal, estado],
    (errDir, dirRes) => {
      if (errDir) {
        console.error(errDir);
        return res.status(500).json({ error: 'Error al guardar dirección' });
      }
      const idDireccion = dirRes.insertId;

      /* 2. insertar usuario */
      const sqlUser = `
        INSERT INTO usuarios
          (nombre, apellidos, correo, contrasena, curp, telefono, fecha_nacimiento)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;
      db.query(sqlUser,
        [nombre, apellidos, correo, contrasena, curp, telefono, fecha_nacimiento],
        (errUser, userRes) => {
          if (errUser) {
            console.error(errUser);
            if (errUser.code === 'ER_DUP_ENTRY') {
              return res.status(409).json({ error: 'El correo ya está registrado' });
            }
            return res.status(500).json({ error: 'Error al registrar usuario' });
          }
          const idUsuario = userRes.insertId;

          /* 3. insertar servicio / contrato */
          const contrato = `CFE-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
          const sqlServ = `
            INSERT INTO servicios (id_usuario, id_direccion, numero_contrato)
            VALUES (?, ?, ?)
          `;
          db.query(sqlServ, [idUsuario, idDireccion, contrato], (errServ) => {
            if (errServ) {
              console.error(errServ);
              return res.status(500).json({ error: 'Usuario y dirección creados, pero falló el contrato' });
            }
            return res.json({ mensaje: 'Usuario, dirección y contrato creados exitosamente' });
          });
        });
    });
});

module.exports = router;
